﻿To add packages to the feed put package files (.nupkg files) in this folder.
NuGet Server will automatically copy the package to the correct location.